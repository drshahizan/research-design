import torch.nn as nn

class EarlyFusionMLP(nn.Module):
    def __init__(self, url_dim, html_dim, hidden=512, num_classes=2):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(url_dim + html_dim, hidden),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden, num_classes),
        )

    def forward(self, url_emb, html_emb):
        x = torch.cat([url_emb, html_emb], dim=1)
        return self.fc(x)
