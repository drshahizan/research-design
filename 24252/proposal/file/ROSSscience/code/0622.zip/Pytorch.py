import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer, BertModel
from torch.nn import TransformerEncoder, TransformerEncoderLayer

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class URLHTMLDataset(Dataset):
    def __init__(self, records):
        self.records = records
        self.url_tok = BertTokenizer.from_pretrained('bert-base-uncased')
        self.url_model = BertModel.from_pretrained('bert-base-uncased')
        self.html_tok = self.url_tok
        self.html_model = self.url_model
    def __len__(self):
        return len(self.records)
    def __getitem__(self, idx):
        url, html, label = self.records[idx]
        ut = self.url_tok(url, return_tensors="pt", truncation=True, padding="max_length")
        url_emb = self.url_model(**ut).pooler_output.squeeze(0)
        ht = self.html_tok(html[:512], return_tensors="pt", truncation=True, padding="max_length")
        html_emb = self.html_model(**ht).pooler_output.squeeze(0)
        fusion = torch.cat([url_emb, html_emb], dim=-1)
        return fusion, torch.tensor(label)

class FusionMLP(nn.Module):
    def __init__(self, emb_dim, hidden=512):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(emb_dim, hidden),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden, 2)
        )
    def forward(self, x):
        return self.fc(x)

# 🛠 构造数据
data = [
    ("http://example.com/path", "<html>...</html>", 0),
    ("http://phish.com/login", "<html>...</html>", 1),
    # ...
]

ds = URLHTMLDataset(data)
loader = DataLoader(ds, batch_size=16, shuffle=True)

# 🔧 模型训练
emb_dim = 768 * 2
model = FusionMLP(emb_dim).to("cpu")
opt = torch.optim.AdamW(model.parameters(), lr=2e-5)
loss_fn = nn.CrossEntropyLoss()

# 🌀 正式训练 Loop
for ep in range(3):
    total, correct = 0, 0
    for x, y in loader:
        logits = model(x)
        loss = loss_fn(logits, y)
        opt.zero_grad(); loss.backward(); opt.step()
        total += y.size(0)
        correct += (logits.argmax(1) == y).sum().item()
    print(f"Epoch {ep}: Acc={(correct/total):.4f}")
# 假设已有 dataset 返回 url_emb 和 html_emb
fusion = TransformerEncoder(
    nn.TransformerEncoderLayer(d_model=768*2, nhead=8),
    num_layers=2
).to(device)

mlp = nn.Sequential(
    nn.Linear(768*2, 256),
    nn.ReLU(),
    nn.Dropout(0.1),
    nn.Linear(256, 2)
).to(device)

for ep in range(5):
    # 取出 batch 后
    x = torch.cat([url_emb, html_emb], dim=1)
    x = fusion(x.unsqueeze(1)).squeeze(1)
    logits = mlp(x)
