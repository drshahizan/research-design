import torch
from torch.utils.data import Dataset
from transformers import BertTokenizer, BertModel, AutoTokenizer, AutoModel

class EarlyFusionDataset(Dataset):
    def __init__(self, url_csv, html_txt, url_model_name='bfilar/urltran', bert_model_name='bert-base-uncased', max_html_len=512):
        import pandas as pd
        self.urls = pd.read_csv(url_csv)['url'].tolist()
        with open(html_txt, 'r', encoding='utf-8') as f:
            self.htmls = f.read().splitlines()
        assert len(self.urls) == len(self.htmls), "URL 数量与 HTML 行数不一致！"

        self.url_tok = AutoTokenizer.from_pretrained(url_model_name)
        self.url_model = AutoModel.from_pretrained(url_model_name).to(device)

        self.bert_tok = BertTokenizer.from_pretrained(bert_model_name)
        self.bert_model = BertModel.from_pretrained(bert_model_name).to(device)

    def __len__(self):
        return len(self.urls)

    def __getitem__(self, idx):
        url = self.urls[idx]
        html = self.htmls[idx][:self.bert_tok.model_max_length]

        # URL embedding
        ut = self.url_tok(url, return_tensors='pt', truncation=True, padding='max_length', max_length=128).to(device)
        u_emb = self.url_model(**ut).last_hidden_state[:,0].squeeze()

        # HTML embedding
        ht = self.bert_tok(html, return_tensors='pt', truncation=True, padding='max_length', max_length=512).to(device)
        h_emb = self.bert_model(**ht).pooler_output.squeeze()

        # label placeholder, 假设后续你设置 label 列或文件中已有
        label = torch.tensor(0, dtype=torch.long)
        return u_emb, h_emb, label
