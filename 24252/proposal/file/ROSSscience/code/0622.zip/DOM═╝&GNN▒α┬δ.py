import os
from bs4 import BeautifulSoup
import networkx as nx
import torch
from torch_geometric.utils.convert import from_networkx
from torch_geometric.data import Data

def html_to_graph(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    G = nx.DiGraph()
    node_id = 0

    # 遍历 DOM 树，用 BFS 构建节点与边
    queue = [(soup, None)]
    while queue:
        node, parent_id = queue.pop(0)
        curr_id = node_id
        G.add_node(curr_id, tag=node.name or 'text', attrs=len(node.attrs))
        if parent_id is not None:
            G.add_edge(parent_id, curr_id)
        node_id += 1

        for child in node.children:
            if hasattr(child, 'name'):
                queue.append((child, curr_id))

    return G

def networkx_to_pyg(G):
    data = from_networkx(G)
    # 将节点属性转为 PyG 特征张量（使用 attrs 作为示例）
    x = torch.tensor([G.nodes[i]['attrs'] for i in G.nodes], dtype=torch.float).view(-1, 1)
    data.x = x
    return data

def load_html_dir(dir_path):
    pyg_graphs = []
    for fname in os.listdir(dir_path):
        if fname.endswith('.html'):
            path = os.path.join(dir_path, fname)
            html = open(path, 'r', encoding='utf-8').read()
            G = html_to_graph(html)
            pyg = networkx_to_pyg(G)
            pyg_graphs.append(pyg)
    return pyg_graphs

if __name__ == '__main__':
    html_folder = r'E:\date\Pycharm\PythonProject_Phish\data\htmls'
    graphs = load_html_dir(html_folder)
    print(f'Loaded {len(graphs)} graphs, each with x shape {graphs[0].x.shape}')
