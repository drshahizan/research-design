import torch
from torch.utils.data import DataLoader
from EarlyFusionDataset import EarlyFusionDataset
from 融合模型 import EarlyFusionMLP

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

ds = EarlyFusionDataset('Openphish.csv', 'top1000.txt')
loader = DataLoader(ds, batch_size=16, shuffle=True)

model = EarlyFusionMLP(url_dim=ds.url_model.config.hidden_size,
                       html_dim=ds.bert_model.config.hidden_size).to(device)
opt = torch.optim.Adam(model.parameters(), lr=1e-4)
loss_fn = nn.CrossEntropyLoss()

for ep in range(5):
    total, correct = 0, 0
    for u,h,y in loader:
        u, h, y = u.to(device), h.to(device), y.to(device)
        logits = model(u, h)
        loss = loss_fn(logits, y)
        opt.zero_grad()
        loss.backward()
        opt.step()
        pred = logits.argmax(1)
        total += y.size(0)
        correct += (pred==y).sum().item()
    print(f'Epoch {ep} acc = {correct/total:.4f}')
