# data_prep.py
import os
import pandas as pd
from sklearn.model_selection import train_test_split
from bs4 import BeautifulSoup
import torch
from torch.utils.data import Dataset

def load_csv(path):
    return pd.read_csv(path)

def load_html(html_dir):
    html_map = {}
    for fname in os.listdir(html_dir):
        if fname.endswith(".html"):
            with open(os.path.join(html_dir, fname), "r", encoding="utf-8", errors="ignore") as f:
                html_map[fname.replace(".html","")] = f.read()
    return html_map

class PhishDataset(Dataset):
    def __init__(self, df, html_map, url_tokenizer, html_tokenizer, max_len=512):
        self.df = df
        self.html_map = html_map
        self.url_tok = url_tokenizer
        self.html_tok = html_tokenizer
        self.max = max_len

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        url = row['url']
        html = self.html_map.get(row['id'], "")
        html_text = BeautifulSoup(html, "html.parser").get_text()[:self.max]
        url_seq = self.url_tok(url)
        html_seq = self.html_tok(html_text)
        label = torch.tensor(row['label'], dtype=torch.long)
        return html_seq, url_seq, label
