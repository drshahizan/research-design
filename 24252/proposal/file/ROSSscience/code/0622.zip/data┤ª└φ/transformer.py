class FusionClassifier(nn.Module):
    def __init__(self, html_enc, url_enc, hidden_dim=256, num_classes=2):
        super().__init__()
        self.html_enc = html_enc
        self.url_enc = url_enc
        self.attn = nn.MultiheadAttention(128, num_heads=4)
        self.fc = nn.Sequential(
            nn.Linear(256, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim, num_classes)
        )

    def forward(self, html_x, url_x):
        h = self.html_enc(html_x)
        u = self.url_enc(url_x)
        q = h.unsqueeze(0); kv = u.unsqueeze(0)
        attn_out, _ = self.attn(q, kv, kv)
        fused = torch.cat([attn_out.squeeze(0), h], dim=1)
        return self.fc(fused)
