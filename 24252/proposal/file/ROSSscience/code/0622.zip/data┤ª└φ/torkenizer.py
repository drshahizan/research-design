# tokenizer.py
from collections import defaultdict

class CharTokenizer:
    def __init__(self):
        self.v2i = defaultdict(lambda: 1)
        self.v2i["<PAD>"] = 0
        self.v2i["<UNK>"] = 1

    def build_vocab(self, texts):
        for t in texts:
            for ch in t:
                if ch not in self.v2i:
                    self.v2i[ch] = len(self.v2i)

    def __call__(self, text, max_len=512):
        seq = [self.v2i.get(ch, self.v2i["<UNK>"]) for ch in text[:max_len]]
        seq += [0]* (max_len - len(seq))
        return torch.tensor(seq)
