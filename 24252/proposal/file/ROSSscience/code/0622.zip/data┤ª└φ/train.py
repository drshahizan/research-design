# train.py
import os
import pandas as pd
from bs4 import BeautifulSoup
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from collections import defaultdict

# ——— Early Stopping ——————————————————
class EarlyStopper:
    def __init__(self, patience=3, min_delta=0.0):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = float('inf')

    def early_stop(self, val_loss):
        if val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1
        return self.counter >= self.patience

# ——— Tokenizer ——————————————————
class CharTokenizer:
    def __init__(self):
        self.v2i = defaultdict(lambda: 1)
        self.v2i["<PAD>"], self.v2i["<UNK>"] = 0, 1

    def build_vocab(self, texts):
        for t in texts:
            for ch in t:
                self.v2i.setdefault(ch, len(self.v2i))

    def __call__(self, txt, max_len=512):
        seq = [self.v2i.get(ch, 1) for ch in txt[:max_len]]
        seq += [0]*(max_len - len(seq))
        return torch.tensor(seq)

# ——— CNN Encoder ——————————————————
class CNNEncoder(nn.Module):
    def __init__(self, vocab_size, embed_dim=64, out_dim=128):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.conv = nn.Sequential(
            nn.Conv1d(embed_dim, out_dim, 7, padding=3), nn.ReLU(),
            nn.MaxPool1d(3),
            nn.Conv1d(out_dim, out_dim, 7, padding=3), nn.ReLU(),
            nn.AdaptiveMaxPool1d(1)
        )

    def forward(self, x):
        x = self.embed(x).permute(0, 2, 1)
        return self.conv(x).squeeze(-1)

# ——— Fusion Classifier ——————————————————
class FusionClassifier(nn.Module):
    def __init__(self, html_enc, url_enc, hidden_dim=256, num_classes=2):
        super().__init__()
        self.html_enc = html_enc
        self.url_enc = url_enc
        self.attn = nn.MultiheadAttention(128, num_heads=4)
        self.fc = nn.Sequential(
            nn.Linear(256, hidden_dim), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(hidden_dim, num_classes)
        )

    def forward(self, html_x, url_x):
        h = self.html_enc(html_x)
        u = self.url_enc(url_x)
        attn_out, _ = self.attn(h.unsqueeze(0), u.unsqueeze(0), u.unsqueeze(0))
        fused = torch.cat([attn_out.squeeze(0), h], dim=1)
        return self.fc(fused)

# ——— Dataset ——————————————————
class PhishDataset(Dataset):
    def __init__(self, df, html_dir, url_tok, html_tok, max_len=512):
        self.df = df
        self.html_dir = html_dir
        self.url_tok = url_tok
        self.html_tok = html_tok
        self.max_len = max_len

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        url = str(row['url'])
        label = int(row['status'])
        html_path = os.path.join(self.html_dir, f"{url}.html")
        html_content = ""
        if os.path.exists(html_path):
            html_content = open(html_path, encoding="utf8", errors="ignore").read()
        text = BeautifulSoup(html_content, "html.parser").get_text()[:self.max_len]
        return self.html_tok(text), self.url_tok(url), torch.tensor(label)

def main():
    # 1. Load data
    df = pd.read_csv("../DATA/new_data_urls.csv")
    print("Columns:", df.columns.tolist(), "| Label counts:", df['status'].value_counts().to_dict())

    # 2. Tokenizers
    url_tok = CharTokenizer()
    html_tok = CharTokenizer()
    url_tok.build_vocab(df['url'].astype(str).tolist())

    html_dir = "../DATA/downloaded_html"
    html_texts = []
    for fn in os.listdir(html_dir):
        if fn.endswith(".html"):
            html_texts.append(open(os.path.join(html_dir, fn), encoding="utf8", errors="ignore").read())
    html_tok.build_vocab(html_texts)

    # 3. Split data
    train_df, val_df = train_test_split(df, test_size=0.2, stratify=df['status'], random_state=42)
    train_loader = DataLoader(PhishDataset(train_df, html_dir, url_tok, html_tok), batch_size=32, shuffle=True)
    val_loader = DataLoader(PhishDataset(val_df, html_dir, url_tok, html_tok), batch_size=32)

    # 4. Device, model, optimizer, loss
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print("Using device:", device)

    html_enc = CNNEncoder(len(html_tok.v2i))
    url_enc = CNNEncoder(len(url_tok.v2i))
    model = FusionClassifier(html_enc, url_enc).to(device)

    opt = optim.Adam(model.parameters(), lr=1e-3)
    crit = nn.CrossEntropyLoss()
    stopper = EarlyStopper(patience=3, min_delta=1e-4)

    # 5. Training loop
    for epoch in range(50):
        print(f"== Epoch {epoch} ==")
        model.train()
        for i, (h, u, y) in enumerate(train_loader):
            h, u, y = h.to(device), u.to(device), y.to(device)
            opt.zero_grad()
            loss = crit(model(h, u), y)
            loss.backward()
            opt.step()
            if i % 200 == 0:
                print(f"  Training batch {i}/{len(train_loader)}")

        # Validation
        model.eval()
        total_loss = total = correct = 0
        with torch.no_grad():
            for h, u, y in val_loader:
                h, u, y = h.to(device), u.to(device), y.to(device)
                logits = model(h, u)
                total_loss += crit(logits, y).item() * len(y)
                correct += (logits.argmax(1) == y).sum().item()
                total += len(y)
        val_loss, val_acc = total_loss/total, correct/total
        print(f"Epoch {epoch:02d}: val_loss={val_loss:.4f}, val_acc={val_acc:.4f}")

        torch.save(model.state_dict(), "best_fusion.pt")
        if stopper.early_stop(val_loss):
            print("Early stopping triggered.")
            break

    # Final evaluation
    model.load_state_dict(torch.load("best_fusion.pt", map_location=device))
    print(f"Final Validation Accuracy: {val_acc:.4f}")

if __name__ == "__main__":
    main()
