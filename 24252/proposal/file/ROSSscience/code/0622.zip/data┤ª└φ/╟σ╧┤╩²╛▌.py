import pandas as pd
from urllib.parse import urlparse, urlunparse, quote
import argparse
from urllib.parse import parse_qsl, urlencode

def normalize_url(u: str) -> str:
    try:
        p = urlparse(u.strip())
        scheme = p.scheme or 'http'
        netloc = p.netloc.lower()
        path = quote(p.path or '/')
        query = dict(parse_qsl(p.query))
        return urlunparse((scheme, netloc, path, '', '', ''))
    except Exception:
        allowed = {k: v for k, v in query.items() if k in ['id', 'ref', 'token']}
        query_str = urlencode(sorted(allowed.items()))
        return urlunparse((scheme, netloc, path, '', query_str, ''))

def clean_csv(path: str, url_col: str) -> pd.DataFrame:
    df = pd.read_csv(path, dtype=str)
    df = df.dropna(subset=[url_col]).copy()
    df['url_norm'] = df[url_col].map(normalize_url)
    df = df.dropna(subset=['url_norm'])
    df = df.drop_duplicates(subset=['url_norm']).reset_index(drop=True)
    return df[['url_norm']]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--verified', default='verified_online.csv')
    parser.add_argument('--openphish', default='openphish.csv')
    args = parser.parse_args()

    df_verified = clean_csv(args.verified, url_col='url')
    df_open = clean_csv(args.openphish, url_col='raw_url')

    df_verified.to_csv('verified_cleaned.csv', index=False)
    df_open.to_csv('openphish_cleaned.csv', index=False)

    combined = pd.concat([df_verified, df_open], ignore_index=True)
    combined = combined.drop_duplicates(subset=['url_norm']).reset_index(drop=True)
    combined.to_csv('all_cleaned_urls.csv', index=False)

    print(f"Verified 清洗后：{len(df_verified)} 条")
    print(f"OpenPhish 清洗后：{len(df_open)} 条")
    print(f"合并去重后共：{len(combined)} 条")

if __name__ == '__main__':
    main()
