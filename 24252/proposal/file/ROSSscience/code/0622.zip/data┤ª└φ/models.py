# models.py
import torch.nn as nn

class CNNEncoder(nn.Module):
    def __init__(self, vocab_size, embed_dim=64, out_dim=128):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.conv = nn.Sequential(
            nn.Conv1d(embed_dim, out_dim, kernel_size=7, padding=3),
            nn.ReLU(),
            nn.MaxPool1d(3),
            nn.Conv1d(out_dim, out_dim, 7, padding=3),
            nn.ReLU(),
            nn.AdaptiveMaxPool1d(1)
        )
    def forward(self, x):
        x = self.embed(x).permute(0,2,1)
        return self.conv(x).squeeze(-1)
